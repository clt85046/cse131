package QProject;

public interface Draw {
	public void draw();
}
