package project;

public interface collision {
	public int collide(Alien aliens,Player player);
}
