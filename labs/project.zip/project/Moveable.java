package project;

public interface Moveable {
	public void move();
	public void draw();
}
