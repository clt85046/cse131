package lab10;

public interface move {
	//public void collided();
	public void move();

}
