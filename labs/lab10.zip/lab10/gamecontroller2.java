package lab10;

import sedgewick.StdDraw;

public class gamecontroller2 {
	private Enemy enemy;
	private Player player;
	public gamecontroller2(Enemy enemy,Player player){
		this.enemy = enemy;
		this.player = player;
		while(true){
			StdDraw.setPenColor(StdDraw.WHITE);
			StdDraw.filledSquare(0, 0, 1.2);
			enemy.move();
			enemy.shoot();
			player.move();
			player.shoot();
			player.collided(enemy);
			StdDraw.show(300); 
		}
	}

}
