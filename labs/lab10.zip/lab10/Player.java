package lab10;

import java.util.LinkedList;

import sedgewick.StdDraw;

public class Player implements move {
	private double x,y,radius,speed,initialx,initialy;
	private LinkedList<bullet> bullets;
	private boolean active;
	public Player(double x,double y,double radius,double speed){
		this.x = x;
		this.y = y;
		this.active = true;
		this.radius = radius;
		this.speed = speed;
		this.bullets = new LinkedList<bullet>();
		initialx = x;
 		initialy = y;
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledSquare(x,y,radius);
		//move();
	}
	public double getx(){
		return x;
	}
	public double gety(){
		return y;
	}
	public double getradius(){
		return radius;
	}
	public double getspeed(){
		return speed;
	}
 	public void move(){

 		if(active == true){
 			if(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_RIGHT)&&(x<1)){
 				x = x +speed;
 			}
 			if(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_LEFT)&&(x>0)){
 				x = x - speed;
 			}
 			StdDraw.setPenColor(StdDraw.BLACK);
 			StdDraw.filledSquare(x,y,radius);
 			if(bullets != null){
 				
 				for(bullet BULLET : bullets){
 					BULLET.move();
 				}
 				
 			}
 			
 		}
 		else{
 			StdDraw.setPenColor(StdDraw.BLACK);
 			StdDraw.filledSquare(initialx,initialy,radius);
 			active = true;
 			x=initialx;
 			y=initialy;
 		}
 	}
 	
 	public void shoot(){
 		if(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_UP)&&(x>0)){
				bullet b = new bullet(x,y,radius,speed);
				bullets.add(b);
				//System.out.println(b);
				
				//bullets = b;
				//bullets.move();
			}
 	}
 	
 	public void collided(Enemy e){
 		LinkedList<bullet> enemy_bullets = e.getbullets();//System.out.println(enemy_bullets);
 		for(bullet e_b : enemy_bullets){
 			//System.out.println(e_b);
 			double b_x = e_b.getx();
 			double b_y = e_b.gety();
 			double b_r = e_b.getr();
 	
 			for(double i = b_x-b_r;i<b_x+b_r;i++){
 				for(double j = b_y-b_r;j<b_y+b_r;j++){
 					if(i<=x+radius&&i>x-radius&&j<=y+radius&&j>=y-radius){
 						System.out.println("work!");
 						active = false;break;
 					}
 				}
 				if(active == false){
 					break;
 				}
 			}
 		}
 		
 	}
 	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Player k = new Player(0.5,0,0.05,0.05);
//	bullet b = new bullet(0.5,0.5,0.05);
//	LinkedList<bullet> bullets = new LinkedList<bullet>();
//	bullets.add(b);
//	for(bullet s : bullets){
//		s.move();
//	}
	
//		while(true){
//			while (!StdDraw.hasNextKeyTyped())
// 			{
// 				StdDraw.pause(100);
// 			}
//			System.out.println(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_RIGHT));
//		}
			
		
	}

}
