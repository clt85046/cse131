package lab10;

import sedgewick.StdDraw;

public class bullet implements move{
	private double x,y,radius,speed;

	public bullet(double x,double y,double radius,double speed){
		this.x = x;
		this.y = y+2*speed;
		this.radius = radius;
		this.speed = speed;
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledRectangle(x, y, radius/2, radius);
		
		//this.shooted = false;
	}
	public double getx(){
		return x;
	}
	public double gety(){
		return y;
	}
	public double getr(){
		return radius;
	}
	public void collided(){
		
	}
	
	public void move(){
			y = y+ speed;
		
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.filledRectangle(x, y, radius/2, radius);
			
	
		
	}
}
