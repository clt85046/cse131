package lab10;

import java.util.LinkedList;

import sedgewick.StdDraw;

public class Enemy implements move {
	private int enemy_num,shottime;
	private double speed,radius;
	private double[] rx;
	private double[] ry;
	private LinkedList<bullet> bullets;
	public Enemy(int num,double speed,double radius){
		this.enemy_num = num;
		this.speed = speed;
		this.radius = radius;
		this.shottime = 0;
		this.rx = new double[enemy_num];
		this.ry = new double[enemy_num];
		this.bullets = new LinkedList<bullet>();
		for (int i = 0;i<enemy_num;i++){
			int k = i/4;
			ry[i] = 1-2*radius*k;
			rx[i] = (2*(i-4*k))*speed;
		}
		//setenemy();
	}
	public LinkedList<bullet> getbullets(){
		return bullets;
	}
	public double[] getrx(){
		return rx;
	}
	public double[] getry(){
		return ry;
	}
	public double getradius(){
		return radius;
	}
	public double getspeed(){
		return speed;
	}
	public int getEnemynum(){
		return enemy_num;
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		if(rx[0]+speed>0&&rx[enemy_num-1]+speed<1.0){
			for(int i = 0;i<enemy_num;i++){
				rx[i] = rx[i]+speed;
				StdDraw.setPenColor(StdDraw.BLACK); 
				StdDraw.filledCircle(rx[i], ry[i], radius); 
			}
		}
		else{
			this.speed = -1*this.speed;
			for(int i = 0;i<enemy_num;i++){
				ry[i] = ry[i]-radius;
				StdDraw.setPenColor(StdDraw.BLACK); 
				StdDraw.filledCircle(rx[i], ry[i], radius); 
			}
			
		}
		if(bullets != null){
				
				for(bullet BULLET : bullets){
					BULLET.move();
				}
				
			}
	}
	
	public void shoot(){
		int k = enemy_num-4;
		int t = (int) (Math.random()*4)+k;
		if(shottime%8==0){
			
			bullet e_b = new bullet(rx[t],ry[t],radius,-0.03);
			bullets.add(e_b);
		}
		shottime++;
		if(shottime == 31){
			shottime = 0;
		}
	}
	
	public void collided(){
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


}
