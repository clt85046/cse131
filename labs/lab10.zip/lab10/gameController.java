package lab10;

import sedgewick.StdDraw;

public class gameController {
	private Enemy enemy;
	private Player player;
	public gameController(Enemy enemy,Player player){
		this.enemy = enemy;
		this.player = player;
		move();
	}
	public void move(){
		double[] e_rx = enemy.getrx();
		double[] e_ry = enemy.getry();
		double e_speed = enemy.getspeed();
		double e_radius = enemy.getspeed();
		int e_enemy_num = enemy.getEnemynum();
		double x = player.getx();
		double y = player.gety();
		double radius = player.getradius();
		double speed = player.getspeed();
		int nums = 0;
		while(e_ry[0]!=e_radius){
			StdDraw.setPenColor(StdDraw.WHITE);
			StdDraw.filledSquare(0, 0, 1.2);
			if(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_RIGHT)&&(x<1)){
				x = x +speed;
			}
			if(ArcadeKeys.isKeyPressed(0, ArcadeKeys.KEY_LEFT)&&(x>0)){
				x = x -speed;
			}
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.filledSquare(x,y,radius);
				
			
			if(e_rx[e_enemy_num-1]+e_speed>1.0||(e_rx[nums]+e_speed<0.0)){
				for(int j = 0;j<e_enemy_num;j++){
					e_ry[j] = e_ry[j] - 2*e_radius;
					StdDraw.setPenColor(StdDraw.BLACK); 
					StdDraw.filledCircle(e_rx[j],e_ry[j], e_radius); 
				}
				e_speed = e_speed* -1;
				nums = 0;
			}
			else{
				while(nums<e_enemy_num){
					e_rx[nums] = e_rx[nums]+2*e_speed; 
					StdDraw.setPenColor(StdDraw.BLACK); 
					StdDraw.filledCircle(e_rx[nums], e_ry[nums],e_radius); 
				
					nums++;
				}
				
			}
			
			
			
			StdDraw.show(300); 
			nums = 0;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
