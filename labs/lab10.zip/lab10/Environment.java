package lab10;

import sedgewick.StdDraw;

public class Environment {
	public Environment(){
		 //clear();
		 StdDraw.setPenColor(StdDraw.WHITE);
         StdDraw.filledSquare(0, 0, 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 

	}

}
