package conway;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//
		// The ConwayController and other supporting classes
		//    are found in the labsupport source folder
		// The visual part of this program was designed using
		//    WindowBuilder, which is built into eclipse.
		ConwayController cc = new ConwayController();
		cc.setVisible(true);
	}

}
